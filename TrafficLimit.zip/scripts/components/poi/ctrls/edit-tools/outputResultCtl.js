angular.module('app').controller('OutputResultCtl', ['$scope', function ($scope) {
    $scope.theadInfo = ['操作', '类型', '编号'];
}]);
