/**
 * Created by mali on 2016/6/12.
 */
angular.module('app').controller('SportsVenuesCtl', function ($scope) {
    // $scope.label = $scope.poi.label;
    $scope.sportsVenuesBuildingType = FM.dataApi.Constant.sportsVenuesBuildingType;
});
