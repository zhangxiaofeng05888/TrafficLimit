/**
 * Created by liwanchong on 2016/3/3.
 */
var blankApp = angular.module('app');
blankApp.controller('blankController', function ($scope) {

});
