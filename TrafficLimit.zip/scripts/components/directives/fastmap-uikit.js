angular.module('fastmap.uikit', []);
