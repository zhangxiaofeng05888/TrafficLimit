/**
 * Created by lingLong on 2017/1/12.
 * 批量选择结果
 */
angular.module('app').controller('trackLineCtrl', function ($scope, dsFcc, NgTableParams) {
    var sceneController = fastmap.mapApi.scene.SceneController.getInstance();
    var symbolFactory = fastmap.mapApi.symbol.GetSymbolFactory();
    var symbol = symbolFactory.getSymbol('track_num');
    var feedbackCtrl = fastmap.mapApi.FeedbackController.getInstance();

    var feedback = new fastmap.mapApi.Feedback();
    feedbackCtrl.add(feedback);

    var clearFeedback = function () {
        feedback.clear();
        feedbackCtrl.refresh();
    };

    $scope.copyToLine = function () {
        var linkData = $scope.results;
        var links = [];
        for (var i = 0; i < linkData.rows.length; i++) {
            links.push(linkData.rows[i].pid);
        }
        if (links.length === 0) {
            swal('提示', '没有可以复制的link', 'warning');
            return;
        }
        var params = {
            type: 'SCPLATERESLINK',
            command: 'CREATE',
            dbId: App.Temp.dbId,
            data: {
                groupId: App.Temp.groupId,
                links: links
            }
        };
        dsFcc.copyToLine(params).then(function (data) {
            if (data === '属性值未发生变化') {
                swal('提示', '重复复制，请重新选择', 'warning');
                return;
            }
            if (data !== -1) {
                swal('提示', '复制成功', 'success');
                sceneController.redrawLayerByGeoLiveTypes(['COPYTOLINE']);
                $scope.closeAdvanceSearchPanel();
            }
        });
    };

    $scope.copyToPolygon = function () {
        var linkData = $scope.results;
        var links = [];
        for (var i = 0; i < linkData.rows.length; i++) {
            links.push(linkData.rows[i].pid);
        }
        if (links.length === 0) {
            swal('提示', '没有可以复制的link', 'warning');
            return;
        }
        var params = {
            type: 'SCPLATERESFACE',
            command: 'CREATE',
            dbId: App.Temp.dbId,
            data: {
                groupId: App.Temp.groupId,
                rdlinks: links
            }
        };
        dsFcc.copyToLine(params).then(function (data) {
            if (data === '属性值未发生变化') {
                swal('提示', '重复复制，请重新选择', 'warning');
                return;
            }
            if (data !== -1) {
                swal('提示', '复制成功', 'success');
                sceneController.redrawLayerByGeoLiveTypes(['COPYTOPOLYGON']);
                $scope.closeAdvanceSearchPanel();
            }
        });
    };

    var initialize = function (event, data) {
        $scope.results = data;
        $scope.selectedNums = $scope.results.rows.length;
        $scope.highlightRoad($scope.results.rows);   //  默认高亮第一条数据
    };

    $scope.highlightRoad = function (item) {
        var len = item.length;
        if (len === 0) {
            return;
        }

        $scope.$emit('LocateObject', { feature: {
            geometry: item[0].geometry
        } });  //  定位到第一个点的位置

        feedback.clear();

        for (var i = 0; i < len; i++) {
            var cloneSymbol = FM.Util.clone(symbol);
            cloneSymbol.symbols[1].text = i + 1;
            feedback.add(item[i].geometry, cloneSymbol);
        }

        feedbackCtrl.refresh();
    };

    $scope.positionLine = function (item) {

        $scope.$emit('LocateObject', { feature: {
            geometry: item.geometry
        } });  //  定位到第一个点的位置

    };

    // 关闭搜索面板;
    $scope.closeAdvanceSearchPanel = function () {
        $scope.$emit('CloseInfoPage', { type: 'trackLinePanel' });
    };

    var unbindHandler = $scope.$on('ReloadData', initialize);

    $scope.$on('$destroy', function () {
        clearFeedback();
        feedbackCtrl.del(feedback);
        unbindHandler = null;
    });
});
